export const teamPodTiers = {
  S: [
    {
      id: 1,
      name: "Team mixte",
      hunters: [40, 2, 3, 4], // IDs des chasseurs, incluant Jinwoo
    },
  ],
  A: [
    {
      id: 2,
      name: "Team mixte 2",
      hunters: [40, 5, 6, 7], // IDs des chasseurs, incluant Jinwoo
    },
  ],
  B: [],
  C: [],
  D: [],
};