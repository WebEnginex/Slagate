export const teamBdgTiers = {
  S: [
    {
      id: 1,
      name: "Team mixte",
      hunters: [40, 2, 3, 4, 15, 16, 18], 
    },
  ],
  A: [
    {
      id: 2,
      name: "Team mixte 2",
      hunters: [40, 2, 3, 4, 15, 16, 18],
    },
  ],
  B: [],
  C: [],
  D: [],
};