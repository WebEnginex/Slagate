export const teamJinwooTiers = {
    S: [
      {
        id: 1,
        name: "Full Burst avec Jinwoo",
        hunters: [1, 2, 3, 4],
      },
    ],
    A: [],
    B: [],
    C: [],
    D: [],
  };
  