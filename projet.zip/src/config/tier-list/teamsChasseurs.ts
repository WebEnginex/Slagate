export const teamChasseursTiers = {
  S: [
    {
      id: 1,
      name: "Compo Crit Vent",
      hunters: [1, 2, 3],
    },
  ],
  A: [
    {
      id: 2,
      name: "Tank + Support",
      hunters: [4, 5, 6],
    },
  ],
  B: [],
  C: [],
  D: [],
};
