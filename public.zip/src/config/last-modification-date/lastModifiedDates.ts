export const lastModifiedDates: Record<string, string> = {
    index: "30 Avril 2025",
    tierList: "30 Avril 2025",
    builds: "30 Avril 2025",
    atelier: "30 Avril 2025",
    promoCodes: "30 Avril 2025",
    creators: "30 Avril 2025",
  };