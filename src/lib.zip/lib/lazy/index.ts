// 📦 Export principal pour Lazy Loading
export { LazyImage } from './LazyImage';
export { default } from './LazyImage';
