import { openDB, DBSchema, IDBPDatabase } from 'idb';

// 📋 Interface pour le schéma de la base de données
interface ImageCacheDB extends DBSchema {
  images: {
    key: string; // URL de l'image
    value: {
      url: string;
      blob: Blob;
      cachedAt: number;
      expiresAt: number;
    };
  };
}

// ⚙️ Configuration
const DB_NAME = 'slagate-image-cache';
const DB_VERSION = 1;
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 1 semaine en millisecondes

let dbPromise: Promise<IDBPDatabase<ImageCacheDB>> | null = null;

/**
 * 🔧 Initialise et retourne la base de données IDB
 */
async function getDB(): Promise<IDBPDatabase<ImageCacheDB>> {
  if (!dbPromise) {
    dbPromise = openDB<ImageCacheDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        // Création du store pour les images
        if (!db.objectStoreNames.contains('images')) {
          db.createObjectStore('images', { keyPath: 'url' });
        }
      },
    });
  }
  return dbPromise;
}

/**
 * 📸 Récupère une image depuis le cache IDB
 * @param imageUrl - URL de l'image à récupérer
 * @returns Blob de l'image ou null si pas trouvée/expirée
 */
export async function getImageFromCache(imageUrl: string): Promise<Blob | null> {
  try {
    const db = await getDB();
    const cached = await db.get('images', imageUrl);
    
    if (!cached) {
      return null;
    }
    
    // Vérification de l'expiration
    if (Date.now() > cached.expiresAt) {
      // Image expirée, on la supprime
      await db.delete('images', imageUrl);
      return null;
    }
    
    return cached.blob;
  } catch (error) {
    console.error('Erreur lors de la récupération depuis le cache:', error);
    return null;
  }
}

/**
 * 💾 Sauvegarde une image dans le cache IDB
 * @param imageUrl - URL de l'image
 * @param blob - Blob de l'image à sauvegarder
 */
export async function saveImageToCache(imageUrl: string, blob: Blob): Promise<void> {
  try {
    const db = await getDB();
    const now = Date.now();
    
    await db.put('images', {
      url: imageUrl,
      blob,
      cachedAt: now,
      expiresAt: now + CACHE_DURATION,
    });
  } catch (error) {
    console.error(`[IndexedDB] Erreur lors de la sauvegarde de l'image: ${imageUrl}`, error);
  }
}

/**
 * 🚀 Récupère une image (depuis le cache ou en ligne) et retourne une URL utilisable
 * @param imageUrl - URL de l'image à récupérer
 * @returns URL blob utilisable dans un <img>
 */
export async function fetchAndCacheImage(imageUrl: string): Promise<string> {
  try {
    // 1️⃣ Vérifier le cache d'abord
    const cachedBlob = await getImageFromCache(imageUrl);
    if (cachedBlob) {
      return URL.createObjectURL(cachedBlob);
    }

    // 2️⃣ Si pas en cache, fetch depuis le réseau
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const blob = await response.blob();

    // 3️⃣ Sauvegarder en cache pour la prochaine fois
    await saveImageToCache(imageUrl, blob);

    // 4️⃣ Retourner l'URL blob
    return URL.createObjectURL(blob);
  } catch (error) {
    console.error(`[IndexedDB] Erreur lors du fetch de l'image: ${imageUrl}`, error);
    // En cas d'erreur, retourner l'URL originale comme fallback
    return imageUrl;
  }
}

/**
 * 🧹 Nettoie les images expirées du cache
 */
export async function cleanExpiredImages(): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('images', 'readwrite');
    const store = tx.objectStore('images');
    const cursor = await store.openCursor();
    
    const now = Date.now();
    
    while (cursor) {
      if (cursor.value.expiresAt < now) {
        await cursor.delete();
      }
      await cursor.continue();
    }
    
    await tx.done;
  } catch (error) {
    console.error('Erreur lors du nettoyage du cache:', error);
  }
}

/**
 * 📊 Obtient des statistiques sur le cache
 */
export async function getCacheStats(): Promise<{
  totalImages: number;
  cacheSize: number;
}> {
  try {
    const db = await getDB();
    const allImages = await db.getAll('images');
    
    const totalImages = allImages.length;
    const cacheSize = allImages.reduce((total, item) => total + item.blob.size, 0);
    
    return { totalImages, cacheSize };
  } catch (error) {
    console.error('Erreur lors de la récupération des stats:', error);
    return { totalImages: 0, cacheSize: 0 };
  }
}
