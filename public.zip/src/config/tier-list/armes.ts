
export const weaponTiers = {
  S: [1, 5, 7],
  A: [3, 6],
  B: [2, 8],
  C: [9],
  D: [15],
};
