export const hunterTiers = {
    S: [1, 5, 8],
    A: [2, 4, 9],
    B: [6, 10],
    C: [3, 18],
    D: [15, 22],
  };