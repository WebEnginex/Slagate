# Guide d'implémentation pour les pages

## Objectif
Ce guide décrit les étapes nécessaires pour intégrer les fonctionnalités basées sur IndexedDB (IDB), Lazy Loading, et SWR dans les pages du projet. L'objectif est de garantir une uniformité dans l'implémentation et d'optimiser les performances.

---

## 1. IndexedDB (IDB)
### Utilisation
- Utiliser le module `imageCache` pour gérer le cache des images.
- Fonctionnalités principales :
  - `fetchAndCacheImage(imageUrl: string)` : Récupère une image depuis le cache ou la télécharge et la met en cache.
  - `getImageFromCache(imageUrl: string)` : Récupère une image depuis le cache.
  - `saveImageToCache(imageUrl: string, blob: Blob)` : Sauvegarde une image dans le cache.

### Exemple
```typescript
import { fetchAndCacheImage } from '@/lib/idb/imageCache';

const imageUrl = 'https://example.com/image.png';
const cachedImageUrl = await fetchAndCacheImage(imageUrl);
```

---

## 2. Lazy Loading
### Utilisation
- Utiliser le composant `LazyImage` pour charger les images uniquement lorsqu'elles sont visibles.
- Fonctionnalités principales :
  - `src` : URL de l'image.
  - `alt` : Texte alternatif.
  - `fallbackClassName` : Classes CSS pour le placeholder.
  - `showSpinner` : Affiche un spinner pendant le chargement.

### Exemple
```typescript
import LazyImage from '@/lib/lazy/LazyImage';

<LazyImage
  src="https://example.com/image.png"
  alt="Description de l'image"
  fallbackClassName="bg-gray-800"
  showSpinner={true}
/>
```

---

## 3. SWR
### Utilisation
- Utiliser le hook `useSupabaseFetch` pour récupérer les données depuis Supabase.
- Fonctionnalités principales :
  - `key` : Clé unique pour la requête.
  - `fetcher` : Fonction de récupération des données.

### Exemple
```typescript
import useSupabaseFetch from '@/lib/swr/useSupabaseFetch';

const { data, error } = useSupabaseFetch('supabase:chasseurs', async () => {
  const { data } = await supabase.from('chasseurs').select('*');
  return data;
});
```

---

## 4. Spinner stylé
### Utilisation
- Utiliser un spinner avec un design moderne basé sur Tailwind et ShadCN.
- Fonctionnalités principales :
  - `className` : Classes CSS pour personnaliser le spinner.

### Exemple
```typescript
const Spinner: React.FC<{ className?: string }> = ({ className = "" }) => (
  <div className={`animate-spin rounded-full border-4 border-gray-300 border-t-blue-600 ${className}`}>
    <span className="sr-only">Chargement...</span>
  </div>
);

<Spinner className="w-8 h-8" />
```

---

## 5. Chargement des images lorsqu'elles sont visibles
### Utilisation
- Le composant `LazyImage` utilise `react-intersection-observer` pour charger les images uniquement lorsqu'elles sont visibles dans le viewport.
- Cela limite les requêtes réseau et améliore les performances.

### Exemple
```typescript
import LazyImage from '@/lib/lazy/LazyImage';

<LazyImage
  src="https://example.com/image.png"
  alt="Description de l'image"
  fallbackClassName="bg-gray-800"
  showSpinner={true}
/>
```

---

## Optimisation des requêtes avec SWR
### Fonctionnalités
- SWR optimise les requêtes grâce à :
  - **Mise en cache** : Les données sont mises en cache pour éviter les requêtes répétées.
  - **Revalidation automatique** : Les données sont mises à jour en arrière-plan.
  - **Récupération intelligente** : Les données sont récupérées uniquement lorsque nécessaire.

### Exemple
```typescript
import useSupabaseFetch from '@/lib/swr/useSupabaseFetch';

const { data, error } = useSupabaseFetch('supabase:chasseurs', async () => {
  const { data } = await supabase.from('chasseurs').select('*');
  return data;
});

// Les données sont mises en cache et revalidées automatiquement
```

---

## Modèle d'intégration
### Étapes
1. **Importer les modules nécessaires** : `imageCache`, `LazyImage`, `useSupabaseFetch`.
2. **Utiliser `LazyImage` pour les images** : Remplacer les balises `<img>` par `<LazyImage>`.
3. **Utiliser `useSupabaseFetch` pour les données** : Remplacer les appels directs à Supabase par le hook SWR.
4. **Gérer le cache des images** : Utiliser `fetchAndCacheImage` pour les images non gérées par `LazyImage`.

### Exemple complet
```typescript
import LazyImage from '@/lib/lazy/LazyImage';
import useSupabaseFetch from '@/lib/swr/useSupabaseFetch';
import { fetchAndCacheImage } from '@/lib/idb/imageCache';

const Page = () => {
  const { data: chasseurs, error } = useSupabaseFetch('supabase:chasseurs', async () => {
    const { data } = await supabase.from('chasseurs').select('*');
    return data;
  });

  return (
    <div>
      {chasseurs?.map((chasseur) => (
        <LazyImage
          key={chasseur.id}
          src={chasseur.image}
          alt={chasseur.nom}
          fallbackClassName="bg-gray-800"
          showSpinner={true}
        />
      ))}
    </div>
  );
};

export default Page;
```
