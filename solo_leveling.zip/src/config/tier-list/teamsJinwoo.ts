export const teamJinwooTiers = {
  S: [
    {
      id: 1,
      name: "Team Jin-Woo S",
      hunters: [40, 2, 3, 4], // IDs des chasseurs, incluant Jinwoo
    },
  ],
  A: [
    {
      id: 2,
      name: "Team Jin-Woo A",
      hunters: [40, 5, 6, 7], // IDs des chasseurs, incluant Jinwoo
    },
  ],
  B: [],
  C: [],
  D: [],
};