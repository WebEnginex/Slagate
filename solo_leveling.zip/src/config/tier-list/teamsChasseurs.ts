
export const teamChasseursTiers = {
  S: [
    {
      id: 1,
      name: "Team S-Rank",
      hunters: [1, 2, 3],
    },
  ],
  A: [
    {
      id: 2,
      name: "Team A-Rank",
      hunters: [4, 5, 6],
    },
  ],
  B: [],
  C: [],
  D: [],
};
